# App Flow & Functionality Document

When a user opens this page, they are met with a fixed page filled with Book tiles, which scroll to the side to reveal more book tiles. Users can filter the books by topic, text search, or episode date. Hovering over any tile reveals the title 

The only non-book in the list is the first one, which includes the Acquired Podcast artwork. This tile is cropped on initial load and links to acquired.fm.